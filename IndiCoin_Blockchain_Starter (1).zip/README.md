# Indi Coin
A Dogecoin-style blockchain.

- Name: Indi Coin
- Ticker: INDI
- Total Supply: 99.999 million
- Block Time: 6 minutes
- Consensus: Proof of Work
- Mineable: Yes
